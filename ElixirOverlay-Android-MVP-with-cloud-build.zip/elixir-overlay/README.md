# Elixir Overlay — Android MVP 0.1

Starter Android Studio project for a transparent, movable overlay. The first build is a UI/calculation prototype: elixir changes are manual and do NOT represent automatic Clash Royale detection yet.

## Open
1. Install Android Studio on a computer.
2. Open this folder as a project and allow Gradle sync.
3. Run on an Android device (Android 8.0+).
4. Allow “Display over other apps” and tap “Запустить панель”.

## Current scope
- Standalone app shell
- Movable overlay panel
- Simple elixir counter and spent-elixir tally for testing UI

## Next engineering steps
- Add a foreground service and MediaProjection user-consent flow for screen capture.
- Build card image matching against reference templates, with confidence thresholds and duplicate suppression.
- Calibrate elixir regeneration and double-elixir timing; show estimates as ranges, not exact hidden game state.
- Test on different Android resolutions and with the user's explicit screen-capture permission.

No game memory access, input automation, or server calls are implemented.
