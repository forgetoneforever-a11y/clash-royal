package com.example.elixiroverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private val captureRequest = 501
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 12, 16)
        window.navigationBarColor = Color.rgb(12, 12, 16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(12, 12, 16))
        }
        root.addView(TextView(this).apply {
            text = "ELIXIR OVERLAY"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }, match(LinearLayout.LayoutParams.MATCH_PARENT, 64))
        root.addView(TextView(this).apply {
            text = "Помощник для Clash Royale\n\nВерсия 0.1 — тестовая основа"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }, match(LinearLayout.LayoutParams.MATCH_PARENT, 100))
        status = TextView(this).apply {
            text = "Статус: оверлей не запущен"
            textSize = 14f
            setTextColor(Color.rgb(190, 190, 205))
            gravity = Gravity.CENTER
        }
        root.addView(status, match(LinearLayout.LayoutParams.MATCH_PARENT, 52))
        root.addView(makeButton("1 · Разрешить оверлей") { requestOverlayPermission() }, match(LinearLayout.LayoutParams.MATCH_PARENT, 56))
        root.addView(makeButton("2 · Запустить панель") { startOverlay() }, match(LinearLayout.LayoutParams.MATCH_PARENT, 56))
        root.addView(makeButton("Остановить панель") { stopService(Intent(this, OverlayService::class.java)); status.text = "Статус: остановлено" }, match(LinearLayout.LayoutParams.MATCH_PARENT, 56))
        root.addView(TextView(this).apply {
            text = "Важно: автоматическое распознавание карт ещё не подключено. Текущая оценка демонстрационная."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }, match(LinearLayout.LayoutParams.MATCH_PARENT, 84))
        setContentView(root)
    }

    private fun match(w: Int, h: Int) = LinearLayout.LayoutParams(w, h).apply { bottomMargin = 10 }
    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(45, 45, 58))
        setOnClickListener { action() }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else status.text = "Статус: разрешение оверлея есть"
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Сначала разреши отображение поверх других приложений"
            requestOverlayPermission()
            return
        }
        startService(Intent(this, OverlayService::class.java))
        status.text = "Статус: панель запущена"
    }
}
