package com.example.elixiroverlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var elixir = 5.0
    private var spent = 0
    private var lastTick = System.currentTimeMillis()
    private lateinit var amount: TextView
    private lateinit var spentLabel: TextView

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val bg = GradientDrawable().apply {
            setColor(0xE91A1A22.toInt())
            cornerRadius = 28f
            setStroke(2, 0xFF777788.toInt())
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 12)
            background = bg
        }
        box.addView(TextView(this).apply {
            text = "ELIXIR · CR"
            textSize = 12f
            setTextColor(0xFFB8B8C8.toInt())
        })
        amount = TextView(this).apply {
            text = "≈ ${"%.1f".format(elixir)} / 10"
            textSize = 23f
            setTextColor(Color.WHITE)
        }
        box.addView(amount)
        spentLabel = TextView(this).apply {
            text = "Потрачено: 0 · оценка"
            textSize = 11f
            setTextColor(0xFFD2D2DE.toInt())
        }
        box.addView(spentLabel)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(actionButton("−1") { spend(1) })
        row.addView(actionButton("−2") { spend(2) })
        row.addView(actionButton("+1с") { tick(1.0) })
        row.addView(actionButton("↺") { elixir = 5.0; spent = 0; refresh() })
        box.addView(row)
        box.addView(TextView(this).apply {
            text = "Перетащи за верхнюю часть"
            textSize = 9f
            setTextColor(0xFF9999AA.toInt())
            gravity = Gravity.CENTER
        })
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 18; y = 140 }
        box.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=params.x; startY=params.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-downX).toInt(); val dy=(e.rawY-downY).toInt(); if (kotlin.math.abs(dx)>5 || kotlin.math.abs(dy)>5) moved=true; if (moved) { params.x=startX+dx; params.y=startY+dy; wm.updateViewLayout(box, params) }; return true }
                    MotionEvent.ACTION_UP -> return true
                }; return false
            }
        })
        panel = box
        wm.addView(box, params)
        return START_STICKY
    }

    private fun actionButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(9, 7, 9, 7)
        setBackgroundColor(0xFF393947.toInt())
        setOnClickListener { action() }
    }
    private fun spend(cost: Int) { elixir = max(0.0, elixir - cost); spent += cost; lastTick = System.currentTimeMillis(); refresh() }
    private fun tick(seconds: Double) { elixir = min(10.0, elixir + seconds); refresh() }
    private fun refresh() { amount.text = "≈ ${"%.1f".format(elixir)} / 10"; spentLabel.text = "Потрачено: $spent · вручную" }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
}
